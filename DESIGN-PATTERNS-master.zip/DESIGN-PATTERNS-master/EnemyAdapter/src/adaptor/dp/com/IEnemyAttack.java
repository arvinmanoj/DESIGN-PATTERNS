package adaptor.dp.com;

public interface IEnemyAttack  {
	
	public void smashWithHands();
	public void walkForward();
	public void reactToHuman(String driverName);

}
