package factorypattern.dp.com;

public class Yellow implements Colour {
	public void fill()
	{
		System.out.println("Yellow Colour.");
	}

}
