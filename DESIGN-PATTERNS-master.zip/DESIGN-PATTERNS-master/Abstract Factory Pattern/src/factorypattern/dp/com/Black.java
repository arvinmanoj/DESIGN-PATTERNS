package factorypattern.dp.com;

public class Black implements Colour {
	public void fill()
	{
		System.out.println("Black In Colour.");
	}

}