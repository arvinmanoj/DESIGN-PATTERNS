package factorypattern.dp.com;

public interface Colour {
	void fill();
}
