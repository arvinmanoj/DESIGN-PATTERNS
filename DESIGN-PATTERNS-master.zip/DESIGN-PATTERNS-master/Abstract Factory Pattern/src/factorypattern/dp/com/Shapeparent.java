package factorypattern.dp.com;

public interface Shapeparent {
	void draw();
}
