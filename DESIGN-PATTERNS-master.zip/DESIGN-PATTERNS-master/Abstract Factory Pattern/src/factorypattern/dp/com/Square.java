package factorypattern.dp.com;

public class Square implements Shapeparent {

	@Override
	public void draw()
	{
		System.out.println("This Is SQUARE.");
	}
}
