package factorypattern.dp.com;

public class Triangle implements Shapeparent {
	@Override
	   public void draw()
	   {
		System.out.println("You Are Calling TRIANGLE");
	   }
}
