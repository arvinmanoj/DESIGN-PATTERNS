package factorypattern.dp.com;

public class Purple implements Colour {
	public void fill()
	{
		System.out.println("Purple Colour.");
	}


}
