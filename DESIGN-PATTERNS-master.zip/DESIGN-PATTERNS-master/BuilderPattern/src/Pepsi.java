
public class Pepsi extends ColdDrink {

	@Override
	public String Name() {
		// TODO Auto-generated method stub
		return "Pepsi";
	}

	 
	

}
