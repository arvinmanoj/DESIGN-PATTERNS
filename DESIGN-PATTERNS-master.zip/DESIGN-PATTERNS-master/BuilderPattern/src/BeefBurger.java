
public class BeefBurger extends Burger {

	@Override
	public String Name() {
		// TODO Auto-generated method stub
		return "Beef-Burger";
	}

	@Override
	public Float Price() {
		// TODO Auto-generated method stub
		return 70.0f;
	}

}
