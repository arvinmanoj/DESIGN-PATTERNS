
public class Plate implements Packing {

	@Override
	public String Pack() {
		// TODO Auto-generated method stub
		return "Plate";
	}

}
