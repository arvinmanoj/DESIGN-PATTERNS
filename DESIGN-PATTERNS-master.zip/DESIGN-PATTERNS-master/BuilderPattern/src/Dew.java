
public class Dew extends ColdDrink{

	@Override
	public String Name() {
		// TODO Auto-generated method stub
		return "Dew";
	}

}
