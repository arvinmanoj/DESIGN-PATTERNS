
public interface Item {

	public String Name();
	public Packing Packing();
	
	public Float Price();
}