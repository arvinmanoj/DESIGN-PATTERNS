
public class CheeseBurger extends Burger {

	@Override
	public String Name() {
		// TODO Auto-generated method stub
		return "Cheese-Burger";
	}

	@Override
	public Float Price() {
		// TODO Auto-generated method stub
		return 60.0f;
	}

}
