
public interface Packing {

	public String Pack();
}
