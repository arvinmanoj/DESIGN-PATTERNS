
public class ChickenBurger extends Burger {

	@Override
	public String Name() {
		// TODO Auto-generated method stub
		return "Chicken-Burger";
	}

	@Override
	public Float Price() {
		// TODO Auto-generated method stub
		return 50.0f;
	}

}
