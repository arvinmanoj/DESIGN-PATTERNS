
public class VegBurger extends Burger {

	@Override
	public String Name() {
		// TODO Auto-generated method stub
		return "Veg-Burger";
	}

	@Override
	public Float Price() {
		// TODO Auto-generated method stub
		return 25.0f;
	}

	

	

	

	
	
}
