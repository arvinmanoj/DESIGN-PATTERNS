
public class Coke extends ColdDrink {

	@Override
	public String Name() {
		// TODO Auto-generated method stub
		return "Coke";
	}

	

}
