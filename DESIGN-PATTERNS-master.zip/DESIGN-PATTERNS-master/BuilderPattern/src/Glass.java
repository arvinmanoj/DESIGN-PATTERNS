
public class Glass implements Packing {

	@Override
	public String Pack() {
		// TODO Auto-generated method stub
		return "Glass";
	}

}
