package factorypattern.dp.com;

public class Circle implements shapeparent{

	@Override
	public void draw()
	{
		System.out.println("You Know I am CIRCLE");
	}
}
