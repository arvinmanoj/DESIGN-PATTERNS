package factorypattern.dp.com;

public class Triangle implements shapeparent {
	@Override
	   public void draw()
	   {
		System.out.println("You Are Calling TRIANGLE");
	   }
}
