package factorypattern.dp.com;

public class Square implements shapeparent {

	@Override
	public void draw()
	{
		System.out.println("This Is SQUARE.");
	}
}
