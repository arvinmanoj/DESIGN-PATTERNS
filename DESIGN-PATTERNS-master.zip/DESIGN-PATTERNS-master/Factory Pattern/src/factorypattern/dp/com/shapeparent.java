package factorypattern.dp.com;

public interface shapeparent {
	void draw();
}
